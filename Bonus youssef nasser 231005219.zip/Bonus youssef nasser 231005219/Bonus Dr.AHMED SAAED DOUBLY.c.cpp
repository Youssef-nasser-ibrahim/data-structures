#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* prev;
    Node* next;

    Node(int val) : data(val), prev(nullptr), next(nullptr) {}
};

class DoublyLinkedList {
private:
    Node* head;

public:
    DoublyLinkedList() : head(nullptr) {}




    void insertSorted(int value) {
        Node* newNode = new Node(value);

        if (!head || value < head->data) {
            newNode->next = head;
            if (head) head->prev = newNode;
            head = newNode;
            return;
        }
        Node* temp = head;
        while (temp->next && temp->next->data < value) {
            temp = temp->next;
        }

        newNode->next = temp->next;
        newNode->prev = temp;

        if (temp->next) temp->next->prev = newNode;
        temp->next = newNode;
    }


         void print() const {
        Node* temp = head;
        Node* tail = nullptr;

        cout << "Forward: ";
        while (temp) {
            cout << temp->data << " <-> ";
            tail = temp;
            temp = temp->next;
        }
        cout << "Backward: ";
        while (tail) {
            cout << tail->data << " <-> ";
            tail = tail->prev;
        }
    }


        void makenull() {
        while (head) {
            Node* temp = head;
            head = head->next;
            delete temp;
        }
    }
};


int main() {
    DoublyLinkedList list;

    list.insertSorted(9);
    list.insertSorted(4);
    list.insertSorted(2);
    list.insertSorted(10);
    list.insertSorted(7);

    cout << "Doubly Linked List:";
    list.print();

}
