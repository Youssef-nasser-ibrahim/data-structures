#include<iostream>
using namespace std;
struct Node{
public:
    int data;
    Node*next;

    Node(int value) : data(value), next(nullptr) {}
};

struct LinkedList{
private:
    Node*head;
    public:
    LinkedList() : head(nullptr) {}

    void insertAtBeginning(int value){
        Node*newNode=new Node();
        newNode->data=value;
        newNode->next=head;
        head=newNode;
    }

    void print(){
        Node*temp=head;
        while(temp){
            cout<<temp->data<<"->";
            temp=temp->next;
        }

    }

     void makenull() {
         while (head!=NULL) {
            Node* temp = head;
            head = head->next;
            delete temp;
        }
        cout << "Memory cleaned";
    }




};



int main() {
    LinkedList list;

    list.insertFront(10);
    list.insertFront(16);
    list.insertFront(26);
    list.insertFront(34);
    list.insertFront(50);

    cout << "Linked List: ";
    list.print();


}
