#include <iostream>
using namespace std;

struct Node {
public:
    int data;
    Node* next;

    Node(int val) : data(val), next(nullptr) {}
};

struct SinglyLinkedList {
private:
    Node* head;

public:
    SinglyLinkedList() : head(nullptr) {}



     void insertSorted(int value) {
        Node* newNode = new Node(value);

        if (!head || value < head->data) {
            newNode->next = head;
            head = newNode;
            return;
        }
         Node* temp = head;
        while (temp->next && temp->next->data < value) {
            temp = temp->next;
        }
         newNode->next = temp->next;
        temp->next = newNode;
    }


      void print() const {
        Node* temp = head;
        while (temp) {
            cout << temp->data << " -> ";
            temp = temp->next;
        }
    }



     void makenull() {
        while (head) {
            Node* temp = head;
            head = head->next;
            delete temp;
        }
    }


};


int main() {
    SinglyLinkedList list;

    list.insertSorted(5);
    list.insertSorted(8);
    list.insertSorted(3);
    list.insertSorted(4);

    cout << "Singly Linked List (Sorted): ";
    list.print();

}
